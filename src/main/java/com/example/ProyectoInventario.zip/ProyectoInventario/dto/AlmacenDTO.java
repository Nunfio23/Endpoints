package com.example.ProyectoInventario.dto;

import lombok.Data;

@Data
public class AlmacenDTO {
    private String codigo;
    private String nombre;
    private String tipo;
    private String direccion;
    private String ciudad;
    private String pais;
    private Boolean activo;
}
