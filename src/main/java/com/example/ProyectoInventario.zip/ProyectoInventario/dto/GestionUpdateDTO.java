package com.example.ProyectoInventario.dto;

public class GestionUpdateDTO {
    private String observacion;   // permitir editar observación

    public String getObservacion() { return observacion; }
    public void setObservacion(String observacion) { this.observacion = observacion; }
}
