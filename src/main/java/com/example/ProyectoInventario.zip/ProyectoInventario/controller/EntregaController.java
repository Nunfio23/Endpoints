package com.example.ProyectoInventario.controller;

import com.example.ProyectoInventario.dto.EntregaCreateDTO;
import com.example.ProyectoInventario.dto.EntregaUpdateDTO;
import com.example.ProyectoInventario.dto.EntregaResponseDTO;
import com.example.ProyectoInventario.service.EntregaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/entregas")
@Tag(name = "Entregas", description = "CRUD de entregas con validaciones y DTOs")
@CrossOrigin(origins = "*")
public class EntregaController {

    private final EntregaService service;

    public EntregaController(EntregaService service) {
        this.service = service;
    }

    @Operation(summary = "Listar entregas")
    @GetMapping
    public ResponseEntity<List<EntregaResponseDTO>> listar() {
        List<EntregaResponseDTO> response = service.listarEntidades().stream().map(entrega -> {
            EntregaResponseDTO dto = new EntregaResponseDTO();
            dto.setEntregaId(entrega.getEntregaId());
            dto.setProductoId(entrega.getProducto().getProductoId());
            dto.setAlmacenId(entrega.getAlmacen().getAlmacenId());
            dto.setProductoNombre(entrega.getProducto().getNombre());
            dto.setAlmacenNombre(entrega.getAlmacen().getNombre());
            dto.setCantidad(entrega.getCantidad());
            dto.setFechaEntrega(entrega.getFechaEntrega());
            return dto;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Obtener entrega por ID")
    @GetMapping("/{id}")
    public ResponseEntity<?> obtener(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(service.obtener(id));
        } catch (RuntimeException ex) {
            return ResponseEntity.status(404).body(ex.getMessage());
        }
    }

    @Operation(summary = "Crear entrega")
    @PostMapping
    public ResponseEntity<?> crear(@Valid @RequestBody EntregaCreateDTO dto) {
        try {
            return ResponseEntity.ok(service.crear(dto));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        } catch (Exception ex) {
            return ResponseEntity.internalServerError().body("Error al crear entrega: " + ex.getMessage());
        }
    }

    @Operation(summary = "Actualizar entrega")
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(@PathVariable Long id, @Valid @RequestBody EntregaUpdateDTO dto) {
        try {
            return ResponseEntity.ok(service.actualizar(id, dto));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        } catch (Exception ex) {
            return ResponseEntity.internalServerError().body("Error al actualizar entrega: " + ex.getMessage());
        }
    }

    @Operation(summary = "Eliminar entrega")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        try {
            service.eliminar(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.status(404).body(ex.getMessage());
        }
    }
}
